#include <stdio.h>
#include <stdlib.h>
#include "element.c"
#include "pile_Dynamique.h"

/*typedef struct Cellule{
        ELEMENT element;
        struct Cellule *suiv;}Cellule, *PILE;*/
/*typedef Cellule * PILE;*/

PILE init_PILE(){
     return NULL;
     }
    
void affiche_PILE(PILE paux){
      int i;
      if(PILE_estVide(paux)==1){
         printf("la Pile est vide.\n");}
      else{     printf("Les elements de votre pile sont\n");
                while(PILE_estVide(paux)!=1){
                printf("%d\n",paux->element);
                paux=paux->suiv;}   
         }
}
       
int PILE_estVide(PILE p){return (p==NULL);}

PILE emPILE(PILE pile, ELEMENT entier){ 
    PILE paux;
    paux=(PILE)malloc (sizeof(Cellule));
    if(paux!=NULL){
       paux->element=entier;
       paux->suiv=pile;
       return paux;
    }
    return pile;
}

PILE dePILE(PILE pile, ELEMENT *elementsupp){
    if(PILE_estVide(pile)==1){printf("La Pile est Vide");
    return pile;}
    else {
           PILE paux;
           *elementsupp=pile->element;
           paux=pile->suiv;
           free(pile);
           return paux;
         }
}

PILE saisir_PILE()
{   int combien,i;
    ELEMENT element;
    PILE pile;
    pile =init_PILE();
    printf("Combien d'element voulez-vous saisir: ");
    scanf("%d",&combien);
                for(i=0;i<combien;i++){  
                   element=saisir_ELEMENT();
                   pile=emPILE(pile,element);
                }
    return pile;
}
            
            
          
                 
