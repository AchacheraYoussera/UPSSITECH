#ifndef pile_statique_H_INCLUS    /*--  Inclusion conditionnelle --> si pas déjà inclus           */
#define pile_statique_H_INCLUS
#include "element.h"
  /*--  alors créer la constante symbolique MODULE_IMAGE_H_INCLUS */
/* AUTEUR : YOUSSERA ACHACHERA                      */
/* DATE CREATION : 22/11/2022                    */
/*-------------------------------------------------*/
typedef struct Cellule{
        ELEMENT element;
        struct Cellule *suiv;}Cellule, *PILE;
/* DECLARATIONS DES FONCTIONS */
PILE init_PILE();
void affiche_PILE(PILE p);
int PILE_estVide(PILE p);
PILE emPILE(PILE p, ELEMENT n);
PILE dePILE(PILE p, ELEMENT *n);
PILE saisir_PILE();


#endif
